export const categoryList = [
  "Housing",
  "Clothing",
  "Food",
  "Car expense",
  "Education",
  "Fitness",
  "Subscriptions",
  "Entertainment",
  "Medical Expenses",
];

export const monthsName = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
